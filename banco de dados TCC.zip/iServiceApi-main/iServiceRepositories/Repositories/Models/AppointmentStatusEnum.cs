namespace iServiceRepositories.Repositories.Models
{
    public enum AppointmentStatusEnum
    {
        Novo = 1,
        Confirmado = 2,
        Iniciado = 3,
        Finalizado = 4,
        Cancelado = 5
    }
}
