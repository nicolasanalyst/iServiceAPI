﻿namespace iServiceRepositories.Repositories.Models
{
    public class MonthlyReport
    {
        public int Month { get; set; }
        public int TotalAppointments { get; set; }
        public float AverageRating { get; set; }
    }
}
