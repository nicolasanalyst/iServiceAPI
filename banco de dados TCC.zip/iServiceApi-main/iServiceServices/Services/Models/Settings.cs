﻿namespace iServiceServices.Services.Models
{
    public class Settings
    {
        public static string Secret = "e71a68bb15537a186f5ef79ee18781b1eb28a7f2147bb8daf3928a1be94e7558";
    }
}
